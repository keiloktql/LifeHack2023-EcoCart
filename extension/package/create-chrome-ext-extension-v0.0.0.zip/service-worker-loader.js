import './assets/index.js2.js';
