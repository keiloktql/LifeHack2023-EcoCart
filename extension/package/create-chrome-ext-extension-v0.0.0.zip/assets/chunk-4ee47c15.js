console.info("chrome-ext template-vanilla-js content script");
