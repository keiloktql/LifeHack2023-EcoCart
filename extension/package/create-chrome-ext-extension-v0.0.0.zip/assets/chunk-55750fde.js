import"./chunk-b3cdbad1.js";const e="create-chrome-ext";document.querySelector("#app").innerHTML=`
  <main>
  <h3>Options Page!</h3>

  <h6>v 0.0.0</h6>

  <a
    href="https://www.npmjs.com/package/create-chrome-ext"
    target="_blank"
  >
    Power by ${e}
  </a>
  </main>
`;
